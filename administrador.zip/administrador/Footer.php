


	<script src="TemplateAdministrador/vendors/scripts/core.js"></script>
	<script src="TemplateAdministrador/vendors/scripts/script.min.js"></script>
	<script src="TemplateAdministrador/vendors/scripts/process.js"></script>
	<script src="TemplateAdministrador/vendors/scripts/layout-settings.js"></script>
    <script src="TemplateAdministrador/vendors/scripts/dashboard.js"></script>
    

